define(['require','main'], function (require) {
    console.log('main');
    require(['m1', 'm2'], function(m1, m2){
        console.log(m1);
        console.log(m2);
    });
});