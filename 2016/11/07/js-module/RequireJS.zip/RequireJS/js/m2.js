define(['require','m2'], function (require) {
    console.log('m2');

    var init = function(){
        console.log('m2 init');
    }

    return init;
});