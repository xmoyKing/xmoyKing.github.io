define(['require','m1'], function (require) {
    console.log('m1');
    return function(){
        console.log('m1 return');
    }
});