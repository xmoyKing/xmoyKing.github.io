define(function (require, exports, module) {
    // 通过module.exports提供整个对象,包括内部的所有函数和变量
    // 与上面exports的导出方式不可公用
    var multi = {}; // 预先定义导出对象
    multi.do1 = function(){
        console.log('do1');
    }
    multi.do2 = function(){
        console.log('do2');
    }

    module.exports = multi;
})