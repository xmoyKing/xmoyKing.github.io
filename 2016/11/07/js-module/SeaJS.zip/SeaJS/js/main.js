define(function (require, exports, module) {
    // 异步加载
    require.async('m2', function(m){
        m.do2();
    });
    
    // 同步导入;
    var index = require('m1');
    index.fun1();

})