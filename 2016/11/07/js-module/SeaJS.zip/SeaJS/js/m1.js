define(function (require, exports, module) {
    // 通过exports导出某个函数,
    exports.fun1 = function () {
        console.log('fun1');
    }
    exports.fun2 = function () {
        console.log('fun2');
    }
});